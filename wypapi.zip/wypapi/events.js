const { pool } = require('./config')

//events table
const getEvents = (request, response) => {
  pool.query('SELECT * FROM events', (error, results) => {
    if (error) {
      throw error
    }
    response.status(200).json(results.rows)
  })
}

const createEvent = (request, response) => {
    const { event_name, event_date, event_address, event_location, event_description, event_host } = request.body
  
    pool.query('INSERT INTO events (event_name, event_date, event_address, event_location, event_description, event_host) VALUES ($1, $2, $3, $4, $5, $6)', [event_name, event_date, event_address, event_location, event_description, event_host], (error, result) => {
      if (error) {
        throw error
      }
      response.status(201).send(`Event added with ID: ${result.insertId}`)
    })
}

const getEventById = (request, response) => {
    const id = parseInt(request.params.id)
  
    pool.query('SELECT * FROM events WHERE id = $1', [id], (error, results) => {
      if (error) {
        throw error
      }
      response.status(200).json(results.rows)
    })
}

const updateEvent = (request, response) => {
    const id = parseInt(request.params.id)
    const { event_name, event_date, event_address, event_location, event_description, event_host } = request.body
  
    pool.query(
      'UPDATE events SET event_name = $1, event_date = $2, event_address = $3, event_location = $4, event_description = $5, event_host = $6 WHERE id = $7',
      [event_name, event_date, event_address, event_location, event_description, event_host, id],
      (error, results) => {
        if (error) {
          throw error
        }
        response.status(200).send(`Event modified with ID: ${id}`)
      }
    )
}

const deleteEvent = (request, response) => {
    const id = parseInt(request.params.id)
  
    pool.query('DELETE FROM events WHERE id = $1', [id], (error, results) => {
      if (error) {
        throw error
      }
      response.status(200).send(`Event deleted with ID: ${id}`)
    })
}

  module.exports = {
    getEvents,
    getEventById,
    createEvent,
    updateEvent,
    deleteEvent,
  }