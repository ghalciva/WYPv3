CREATE TABLE users (
    ID SERIAL PRIMARY KEY, 
    user_name VARCHAR(255) NOT NULL,
    genre VARCHAR (255) NOT NULL, 
    phone INTEGER NOT NULL 
);

INSERT INTO users (user_name, genre, phone) 
VALUES ('Gloria', 'Femenino', 0969982075);

CREATE TABLE events (
    ID SERIAL PRIMARY KEY, 
    event_name VARCHAR(255) NOT NULL, 
    event_date DATE NOT NULL, 
    event_address VARCHAR (255) NOT NULL, 
    event_location VARCHAR (255) NOT NULL, 
    event_description VARCHAR (255) NOT NULL, 
    event_host VARCHAR (255) NOT NULL
);

INSERT INTO events (event_name, event_date, event_address, event_location, event_description, event_host) 
VALUES ('End of Semester AP Party', '2020-02-20T21:15:36.874Z', 'Av. Víctor Emilio Estrada 110, Guayaquil 090102', 'https://www.google.com/maps/place/Roof+Club/@-2.1612351,-79.9074752,14.81z/data=!4m8!1m2!2m1!1srooftop+guayaquil!3m4!1s0x0:0xeba7e7eabac0f2ea!8m2!3d-2.1760678!4d-79.9054044', 'Fiesta de fin de semestre para celebrar los AP', 'ASO');