const express = require('express')
const bodyParser = require('body-parser')
const app = express()
const db = require('./queries')
const dbe = require('./events')

app.use(bodyParser.json())
app.use(
  bodyParser.urlencoded({
    extended: true,
  })
)

app.get('/', (request, response) => {
  response.json({ info: 'Node.js, Express, and Postgres API for WYP' })
})

//for users
app.get('/api/users', db.getUsers)
app.get('/api/users/:id', db.getUserById)
app.post('/api/user', db.createUser)
app.put('/api/users/:id', db.updateUser)
app.delete('/api/users/:id', db.deleteUser)

//for events
app.get('/api/events', dbe.getEvents)
app.get('/api/events/:id', dbe.getEventById)
app.post('/api/event', dbe.createEvent)
app.put('/api/events/:id', dbe.updateEvent)
app.delete('/api/events/:id', dbe.deleteEvent)

// Start server
app.listen(process.env.PORT || 3002, () => {
    console.log(`Server listening`)
  })

