const { pool } = require('./config')

//users table
  const getUsers = (request, response) => {
    pool.query('SELECT * FROM users', (error, results) => {
      if (error) {
        throw error
      }
      response.status(200).json(results.rows)
    }
    )
  }
  
  const createUser = (request, response) => {
      const { user_name, genre, phone } = request.body
    
      pool.query('INSERT INTO users (user_name, genre, phone) VALUES ($1, $2, $3)', [user_name, genre, phone], (error, result) => {
        if (error) {
          throw error
        }
        response.status(201).send(`User added with ID: ${result.insertId}`)
      })
  }
  
  const getUserById = (request, response) => {
      const id = parseInt(request.params.id)
    
      pool.query('SELECT * FROM users WHERE id = $1', [id], (error, results) => {
        if (error) {
          throw error
        }
        response.status(200).json(results.rows)
      })
  }
  
  const updateUser = (request, response) => {
      const id = parseInt(request.params.id)
      const { user_name, genre, phone } = request.body
    
      pool.query(
        'UPDATE users SET user_name = $1, genre = $2, phone = $3 WHERE id = $4',
        [user_name, genre, phone, id],
        (error, results) => {
          if (error) {
            throw error
          }
          response.status(200).send(`User modified with ID: ${id}`)
        }
      )
  }
  
  const deleteUser = (request, response) => {
      const id = parseInt(request.params.id)
    
      pool.query('DELETE FROM users WHERE id = $1', [id], (error, results) => {
        if (error) {
          throw error
        }
        response.status(200).send(`User deleted with ID: ${id}`)
      })
  }

module.exports = {
    getUsers,
    getUserById,
    createUser,
    updateUser,
    deleteUser,
}